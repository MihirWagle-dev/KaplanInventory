package com.KaplanInventory.controller;

import com.KaplanInventory.model.Order;
import com.KaplanInventory.model.ProductOrders;
import com.KaplanInventory.service.IOrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
public class OrderController {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private IOrderService orderService;

    @GetMapping("/orders")
    public String findOrders(Model model){
        try {
            List<Order> orderList = (List<Order>) orderService.findAll();
            model.addAttribute("productOrders", orderList);
        } catch (Exception exp) {
            LOGGER.error("Exception occured" , exp);
            throw exp;
        }
        return "orders";
    }

    @GetMapping(path = "/orders/{id}")
    public String findAllById(@PathVariable("id") long id, Model model){
        LOGGER.info("Find by id " + id);
        List<Order> orderListById = (List<Order>) orderService.findAllById(id);
        if(orderListById.isEmpty()){
            LOGGER.error("Order List is empty and does not contain the id " + id);
            throw new NotFoundException();
        }
        model.addAttribute("productOrders", orderListById);
        return "orders";
    }

    @PostMapping("/orders")
    @ResponseBody
    public List<ProductOrders> save(@RequestBody List<ProductOrders> productOrders ){
        LOGGER.info("Post method to insert orders");
        return orderService.saveProductOrders(productOrders);
    }


    @PostMapping("/upload-csv-file")
    public String uploadCSVFile(@RequestParam("file") MultipartFile file, Model model) throws IOException {
        // validate file
        if (file.isEmpty()) {
            model.addAttribute("message", "Please select a CSV file to upload.");
            model.addAttribute("status", false);
            LOGGER.error("upload file failed");
        } else {
            try {
                List<ProductOrders> productOrders = orderService.readCsvProductOrders(file);

                model.addAttribute("productOrders", productOrders);
                model.addAttribute("message", "File uploaded successfully");
                model.addAttribute("status", true);

                LOGGER.info("file uploaded successfully");
            } catch (Exception exp) {
                LOGGER.error("Exception occured" , exp);
                throw exp;
            }
        }

        return "uploadFile";
    }
}