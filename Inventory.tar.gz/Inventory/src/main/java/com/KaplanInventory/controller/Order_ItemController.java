package com.KaplanInventory.controller;

import com.KaplanInventory.model.Order_Item;
import com.KaplanInventory.service.IOrder_ItemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@Controller
public class Order_ItemController {


    private static final Logger LOGGER = LoggerFactory.getLogger(Order_ItemController.class);

    @Autowired
    private IOrder_ItemService order_itemService;

    @GetMapping("/orderItems")
    public String findOrder_Items(Model model){

        try {
            List<Order_Item> order_itemList = (List<Order_Item>) order_itemService.findAll();
            model.addAttribute("productOrders", order_itemList);
        } catch (Exception exp) {
            LOGGER.error("Exception occured" , exp);
            throw exp;
        }
        return "orders";
    }


}