package com.KaplanInventory.controller;

import com.KaplanInventory.model.Product;
import com.KaplanInventory.service.IProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestClientException;

import java.util.List;

@Controller
public class ProductController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductService productService;

    @GetMapping("/")
    public String  index(Model model){
        return "index";
    }

    @GetMapping("/products")
    public String  findProducts(Model model){
        LOGGER.info("find all products");
        List<Product> productList = (List<Product>) productService.findAll();
        model.addAttribute("products", productList);
        return "products";
    }

    @GetMapping(path = "/products/{skuId}")
    public String findAllById(@PathVariable("skuId") long skuId, Model model){
        LOGGER.info("Find by id " + skuId);
        List<Product> productListById = (List<Product>) productService.findAllById(skuId);
        if(productListById.isEmpty()){
            LOGGER.error("Product List is empty and does not contain the skuId " + skuId);
            throw new NotFoundException();
        }
        model.addAttribute("products", productListById);
        return "products";
    }

    @DeleteMapping(path = "/products/{skuId}")
    public String deleteById(@PathVariable("skuId") long skuId){
        LOGGER.info("Delete by id " + skuId);
        try {
            productService.deleteById(skuId);
        } catch (RestClientException exp) {
            LOGGER.error("RestClientException while deleting :", exp);
            throw new RestClientException("Internal Server Error", exp);
        } catch (Exception exp) {
            LOGGER.error("Error while deleting :", exp);
            throw exp;
        }
        return "products";
    }

    @PostMapping(path = "/products")
    public String save(@RequestParam("sku") long sku,
                        @RequestParam("name") String name,
                        @RequestParam("quantity") int quantity,
                        @RequestParam("unit_price") double unit_price,
                       Model model){
        LOGGER.info("Post method to insert a product");
        Product product= new Product(sku, name, quantity, unit_price);
        productService.save(product);
        List<Product> productList = (List<Product>) productService.findAll();
        model.addAttribute("products", productList);
        return "products";
    }

}