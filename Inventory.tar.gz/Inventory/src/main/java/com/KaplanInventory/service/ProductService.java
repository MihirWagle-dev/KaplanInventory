package com.KaplanInventory.service;

import com.KaplanInventory.model.Product;
import com.KaplanInventory.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class ProductService implements IProductService{

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);
    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<Product> findAll() {
        List<Product> productList = (List<Product>) productRepository.findAll();
        LOGGER.info("findAll in ProductService");
        return productList;
    }

    @Override
    public List<Product> findAllById(long skuId) {
        List<Product> productList = (List<Product>) productRepository.findAllById(Collections.singleton(skuId));
        return productList;
    }

    @Override
    public Product save(Product product) {
        return productRepository.save(product);

    }

    @Override
    public void deleteById(long skuId){
        productRepository.deleteById(skuId);
    }

}
