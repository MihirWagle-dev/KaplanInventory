package com.KaplanInventory.service;

import com.KaplanInventory.model.Order;
import com.KaplanInventory.model.ProductOrders;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface IOrderService {

    List<Order> findAll();

    List<Order> findAllById(long id);

    List<ProductOrders> readCsvProductOrders(MultipartFile file) throws IOException;

    void deleteAll();

    List<ProductOrders> saveProductOrders(List<ProductOrders> productOrders);
}
