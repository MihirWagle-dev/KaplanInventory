package com.KaplanInventory.service;

import com.KaplanInventory.model.Order;
import com.KaplanInventory.model.Order_Item;
import com.KaplanInventory.model.Product;
import com.KaplanInventory.model.ProductOrders;
import com.KaplanInventory.repository.OrderRepository;
import com.KaplanInventory.repository.Order_ItemRepository;
import com.KaplanInventory.repository.ProductRepository;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class OrderService implements IOrderService{
    private static final Logger LOGGER = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private Order_ItemRepository order_itemRepository;

    private final List<ProductOrders> productOrders;

    public OrderService() {
        productOrders = new ArrayList();
    }

    @Override
    public List<Order> findAll() {
        List<Order> orderList = (List<Order>)orderRepository.findAll();
        return orderList;
    }

    @Override
    public List<Order> findAllById(long id) {
        List<Order> orderList = (List<Order>) orderRepository.findAllById(Collections.singleton(id));
        return orderList;
    }

    @Override
    public List<ProductOrders> saveProductOrders(List<ProductOrders> productOrders) {
        for(ProductOrders p : productOrders){
            Product product = new Product(p.getSku(), p.getName(), p.getQuantity(), p.getUnit_price());
            Order order = new Order(p.getId(), p.getAmount(), LocalDate.now());
            Order_Item order_item = new Order_Item(p.getOrder_item_id(),
                    p.getSold_quantity(),
                    p.getOrder_item_unit_price(),
                    p.getSku(), p.getId());

            productRepository.save(product);
            orderRepository.save(order);
            order_itemRepository.save(order_item);
        }
        return productOrders;
    }

    @Override
    public List<ProductOrders> readCsvProductOrders(MultipartFile file) throws IOException {
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {

            // create csv bean reader
            CsvToBean<ProductOrders> csvToBean = new CsvToBeanBuilder(reader)
                    .withType(ProductOrders.class)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();

            // convert `CsvToBean` object to list of users
            List<ProductOrders> productOrders = csvToBean.parse();
            saveProductOrders(productOrders);

        } catch (IOException ex) {
            LOGGER.error("Exception occured" , ex);
            throw ex;
        }
        return productOrders;
    }

    @Override
    public void deleteAll(){
        orderRepository.deleteAll();
    }
}
