package com.KaplanInventory.service;

import com.KaplanInventory.model.Product;

import java.util.List;

public interface IProductService {
    List<Product> findAll();
    List<Product> findAllById(long skuId);

    Product save(Product product);

    void deleteById(long skuId);
}
