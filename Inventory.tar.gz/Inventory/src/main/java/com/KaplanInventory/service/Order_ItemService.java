package com.KaplanInventory.service;

import com.KaplanInventory.model.Order_Item;
import com.KaplanInventory.repository.Order_ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Order_ItemService implements IOrder_ItemService{

    @Autowired
    private Order_ItemRepository order_itemRepository;

    @Override
    public List<Order_Item> findAll() {
        List<Order_Item> order_itemList = (List<Order_Item>) order_itemRepository.findAll();
        return order_itemList;
    }

    @Override
    public void deleteAll(){
        order_itemRepository.deleteAll();
    }
}
