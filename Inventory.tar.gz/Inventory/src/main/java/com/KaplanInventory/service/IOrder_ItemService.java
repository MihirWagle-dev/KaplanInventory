package com.KaplanInventory.service;

import com.KaplanInventory.model.Order_Item;

import java.util.List;

public interface IOrder_ItemService {

    List<Order_Item> findAll();

    void deleteAll();
}
