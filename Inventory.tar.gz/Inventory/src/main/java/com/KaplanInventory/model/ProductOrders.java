package com.KaplanInventory.model;

import com.opencsv.bean.CsvBindByName;

public class ProductOrders {
    @CsvBindByName
    private long sku;
    @CsvBindByName
    private String name;
    @CsvBindByName
    private int quantity;
    @CsvBindByName
    private double unit_price;

    @CsvBindByName
    private  long order_item_id;
    @CsvBindByName
    private  int sold_quantity;
    @CsvBindByName
    private  double order_item_unit_price;

    @CsvBindByName
    private long id;
    @CsvBindByName
    private double amount;

    public ProductOrders() {
    }

    public ProductOrders(long sku, String name, int quantity, double unit_price, long order_item_id,
                         int sold_quantity, double order_item_unit_price,
                         long id, double amount) {
        this.sku = sku;
        this.name = name;
        this.quantity = quantity;
        this.unit_price = unit_price;
        this.order_item_id = order_item_id;
        this.sold_quantity = sold_quantity;
        this.order_item_unit_price = order_item_unit_price;
        this.id = id;
        this.amount = amount;
//        this.created_date = created_date;
    }

    public long getSku() {
        return sku;
    }

    public void setSku(long sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }

    public long getOrder_item_id() {
        return order_item_id;
    }

    public void setOrder_item_id(int order_item_id) {
        this.order_item_id = order_item_id;
    }

    public int getSold_quantity() {
        return sold_quantity;
    }

    public void setSold_quantity(int sold_quantity) {
        this.sold_quantity = sold_quantity;
    }

    public double getOrder_item_unit_price() {
        return order_item_unit_price;
    }

    public void setOrder_item_unit_price(double order_item_unit_price) {
        this.order_item_unit_price = order_item_unit_price;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "ProductOrders{" +
                "sku=" + sku +
                ", name='" + name + '\'' +
                ", quantity=" + quantity +
                ", unit_price=" + unit_price +
                ", order_item_id=" + order_item_id +
                ", sold_quantity=" + sold_quantity +
                ", order_item_unit_price=" + order_item_unit_price +
                ", id='" + id + '\'' +
                ", amount=" + amount +
                '}';
    }
}
