package com.KaplanInventory.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;

@Entity
@Table(name = "products")
public class Product {
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty
    private long sku;

    private String name;
    private int quantity;
    private double unit_price;

    public Product() {
    }

    public Product(long sku, String name, int quantity, double unit_price) {
        this.sku = sku;
        this.name = name;
        this.quantity = quantity;
        this.unit_price = unit_price;
    }

    public long getSku() {
        return sku;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getUnit_price() {
        return unit_price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "sku=" + sku +
                ", name='" + name + '\'' +
                ", quantity=" + quantity +
                ", unit_price=" + unit_price +
                '}';
    }
}
