package com.KaplanInventory.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order_items")
public class Order_Item {
    @JsonProperty
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  long order_item_id;

    private  int sold_quantity;
    private  double unit_price;
    private  long product_sku;
    private  long order_id;

    public Order_Item() {
    }

    public Order_Item(long order_item_id, int sold_quantity, double unit_price, long product_sku, long order_id) {
        this.order_item_id = order_item_id;
        this.sold_quantity = sold_quantity;
        this.unit_price = unit_price;
        this.product_sku = product_sku;
        this.order_id = order_id;
    }



    public long getOrder_item_id() {
        return order_item_id;
    }

    public int getSold_quantity() {
        return sold_quantity;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public long getProduct_sku() {
        return product_sku;
    }

    public long getOrder_id() {
        return order_id;
    }

    @Override
    public String toString() {
        return "Order_Item{" +
                "order_item_id=" + order_item_id +
                ", sold_quantity=" + sold_quantity +
                ", unit_price=" + unit_price +
                ", product_sku=" + product_sku +
                ", order_id=" + order_id +
                '}';
    }
}
