package com.KaplanInventory.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "orders")
public class Order {
    @JsonProperty
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private double amount;
    private LocalDate created_date;

    public Order() {
    }

    public Order(long id, double amount, LocalDate created_date) {
        this.id = id;
        this.amount = amount;
        this.created_date = created_date;
    }

    public long getId() {
        return id;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getCreated_date() {
        return created_date;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id='" + id + '\'' +
                ", amount=" + amount +
                ", created_date=" + created_date +
                '}';
    }
}
