package com.KaplanInventory.repository;

import com.KaplanInventory.model.Order_Item;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Order_ItemRepository extends CrudRepository<Order_Item, Long> {
}
