--INSERT INTO cities(name, population) VALUES('Bratislava', 432000);
--INSERT INTO cities(name, population) VALUES('Budapest', 1759000);
--INSERT INTO cities(name, population) VALUES('Prague', 1280000);
--INSERT INTO cities(name, population) VALUES('Warsaw', 1748000);
--INSERT INTO cities(name, population) VALUES('Los Angeles', 3971000);
--INSERT INTO cities(name, population) VALUES('New York', 8550000);
--INSERT INTO cities(name, population) VALUES('Edinburgh', 464000);
--INSERT INTO cities(name, population) VALUES('Berlin', 3671000);


INSERT INTO products(sku, name, quantity, unit_price) VALUES(1, 'book1', 1, 26.99);
INSERT INTO products(sku, name, quantity, unit_price) VALUES(2, 'book2', 1, 38.99);
INSERT INTO products(sku, name, quantity, unit_price) VALUES(3, 'book3', 1, 27.99);


INSERT INTO orders(id, amount, created_date) VALUES(1, 2, '2020-03-03');
INSERT INTO orders(id, amount, created_date) VALUES(2, 3, '2020-03-02');


INSERT INTO order_items(order_item_id, sold_quantity, unit_price, product_sku, order_id) VALUES(1, 9, 5.99, 1, 1);
INSERT INTO order_items(order_item_id, sold_quantity, unit_price, product_sku, order_id) VALUES(2, 3, 3.99, 1, 1);
INSERT INTO order_items(order_item_id, sold_quantity, unit_price, product_sku, order_id) VALUES(3, 9, 5.99, 2, 2);