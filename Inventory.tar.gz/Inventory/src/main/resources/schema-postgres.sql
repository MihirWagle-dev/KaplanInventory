DROP TABLE IF EXISTS cities;
CREATE TABLE cities(id numeric(10) PRIMARY KEY, name VARCHAR(255), population integer);

--INSERT INTO "ORDER" VALUES(1, 2, '2020-03-03')

DROP TABLE IF EXISTS products cascade;
CREATE TABLE products(sku numeric(20) PRIMARY KEY, name VARCHAR(20), quantity numeric(5), unit_price numeric(5,2));


DROP TABLE IF EXISTS orders cascade;
CREATE TABLE orders(id numeric(10) PRIMARY KEY, amount numeric(5,2), created_date date);


DROP TABLE IF EXISTS order_items cascade;
CREATE TABLE order_items(
order_item_id serial PRIMARY KEY,
sold_quantity numeric(5),
unit_price numeric(5,2),
product_sku integer  references products(sku),
order_id integer references orders(id)
);
