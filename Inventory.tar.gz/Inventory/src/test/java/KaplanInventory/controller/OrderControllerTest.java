package KaplanInventory.controller;

import com.KaplanInventory.controller.OrderController;
import com.KaplanInventory.model.Order;
import com.KaplanInventory.service.OrderService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.ui.Model;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderControllerTest {
    @Mock
    private OrderService orderService;

    @Mock
    private Model model;

    @InjectMocks
    private OrderController target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllProducts_whenEmptyProducts(){
//        When
        when(orderService.findAll()).thenReturn(Collections.<Order>emptyList());
//        Assert
        assertEquals(target.findOrders(model), "orders");
    }

    @Test
    public void getOrder_whenOneOrder() {
        Order order = new Order();
        List<Order> orderList = asList(order);
        when(orderService.findAllById(1)).thenReturn(orderList);
//        Assert
        assertEquals(target.findAllById(1, model), "orders");
    }



}