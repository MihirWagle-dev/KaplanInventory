package KaplanInventory.controller;

import com.KaplanInventory.controller.Order_ItemController;
import com.KaplanInventory.model.Order_Item;
import com.KaplanInventory.service.Order_ItemService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.ui.Model;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class Order_ItemControllerTest {
    @Mock
    private Order_ItemService order_itemService;

    @Mock
    private Model model;

    @InjectMocks
    private Order_ItemController target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllOrder_Items_whenEmptyOrder_Items(){
//        When
        when(order_itemService.findAll()).thenReturn(Collections.<Order_Item>emptyList());
//        Assert
        assertEquals(target.findOrder_Items(model), "orders");
    }

    @Test
    public void getOrder_whenOneOrder_Item() {
//        When
        Order_Item order_item = new Order_Item();
        List<Order_Item> order_itemList = asList(order_item);
        when(order_itemService.findAll()).thenReturn(order_itemList);
//        Assert
        assertEquals(target.findOrder_Items(model), "orders");
    }
}