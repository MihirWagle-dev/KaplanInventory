package KaplanInventory.controller;

import com.KaplanInventory.controller.ProductController;
import com.KaplanInventory.model.Product;
import com.KaplanInventory.service.ProductService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.ui.Model;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProductControllerTest {
    @Mock
    private ProductService productService;

    @Mock
    Model model;

    @InjectMocks
    private ProductController target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllProducts_whenEmptyProducts(){
//        When
       when(productService.findAll()).thenReturn(Collections.<Product>emptyList());
//        Assert
        assertEquals(target.findProducts(model), "products");
    }

    @Test
    public void getProduct_whenOneProduct() {
//        When
        Product product = new Product();
        List<Product> productList = asList(product);
        when(productService.findAllById(1)).thenReturn(productList);
//        Assert
        assertEquals(target.findAllById(1, model), "products");
    }

    @Test
    public void saveProducts(){
//        Assert
        assertEquals(target.save(1,"book", 2, 3.45, model), "products");
    }

}