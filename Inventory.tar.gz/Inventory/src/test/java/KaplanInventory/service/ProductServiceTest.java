package KaplanInventory.service;

import com.KaplanInventory.model.Product;
import com.KaplanInventory.repository.ProductRepository;
import com.KaplanInventory.service.ProductService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProductServiceTest {
    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllProducts_whenEmptyProducts(){
//        When
        when(productRepository.findAll()).thenReturn(Collections.<Product>emptyList());
//        Assert
        assertEquals(target.findAll(), Collections.<Product>emptyList());
    }

    @Test
    public void getProduct_whenOneProduct() {
//        When
        Product product = new Product();
        List<Product> productList = asList(product);
        when(productRepository.findAll()).thenReturn(productList);
//        Assert
        assertEquals(target.findAll(), productList);
    }

    @Test
    public void saveProducts(){
//        When
        Product product = new Product();
        when(productRepository.save(product)).thenReturn(product);
//        Assert
        assertEquals(target.save(product), product);
    }


}