package KaplanInventory.service;

import com.KaplanInventory.model.Order;
import com.KaplanInventory.model.Product;
import com.KaplanInventory.repository.OrderRepository;
import com.KaplanInventory.service.OrderService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OrderServiceTest {
    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllOrders_whenEmptyProducts(){
//        When
        when(orderRepository.findAll()).thenReturn(Collections.<Order>emptyList());
//        Assert
        assertEquals(target.findAll(), Collections.<Product>emptyList());
    }

    @Test
    public void getOrder_whenOneOrder() {
//        When
        Order order = new Order();
        List<Order> orderList = asList(order);
        when(orderRepository.findAll()).thenReturn(orderList);
//        Assert
        assertEquals(target.findAll(), orderList);
    }


}