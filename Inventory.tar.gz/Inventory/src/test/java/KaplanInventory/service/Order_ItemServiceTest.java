package KaplanInventory.service;

import com.KaplanInventory.model.Order_Item;
import com.KaplanInventory.model.Product;
import com.KaplanInventory.repository.Order_ItemRepository;
import com.KaplanInventory.service.Order_ItemService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class Order_ItemServiceTest {
    @Mock
    private Order_ItemRepository order_itemRepository;

    @InjectMocks
    private Order_ItemService target;

    @Before
    public void setup(){

    }

    @Test
    public void getAllOrder_Items_whenEmptyOrder_Items(){
//        When
        when(order_itemRepository.findAll()).thenReturn(Collections.<Order_Item>emptyList());
//        Assert
        assertEquals(target.findAll(), Collections.<Product>emptyList());
    }

    @Test
    public void getOrderItems() {
//        When
        Order_Item order_item = new Order_Item();
        List<Order_Item> order_itemList = asList(order_item);
        when(order_itemRepository.findAll()).thenReturn(order_itemList);
//        Assert
        assertEquals(target.findAll(), order_itemList);
    }

}